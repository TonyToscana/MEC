%% Exploraci�n del Hardware disponible 
Dispositivos=daq.getDevices 
Dispositivos=Dispositivos(1);

%% Creaci�n de la sesi�n 
Sesion=daq.createSession(Dispositivos.Vendor.ID)

%% Inicializaci�n del canal 0 para la lectura en voltios referida a masa
CanalIn = addAnalogInputChannel(Sesion, Dispositivos.ID, 0, 'Voltage')
CanalIn.InputType = 'SingleEnded'

%% %Inicializaci�n del canal 0 para la escritura en voltios 
CanalOut = addAnalogOutputChannel(Sesion, Dispositivos.ID, 0, 'Voltage')

%% Lectura en voltios por el canal de entrada configurado 
Lectura = Sesion.inputSingleScan() 

%%  Escritura en voltios por el canal de salida configurado 
SalidaVolts = 0 %Voltios de salida entre -10 y +10 
outputSingleScan(Sesion,SalidaVolts)

% Al finalizar el programa hay que quitar la sesi�n 
release(Sesion); 

