Fs = 8000;
dt = 1/Fs;
StopTime = 0.25; %seconds
T = 0:dt:StopTime-dt;
tic();
time = toc();
disp(time);
SINE = 5 * sin(2 * pi * 55 * T);
%disp(SINE);
%plot(T, SINE);