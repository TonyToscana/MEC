% Ejercicio 4

Amplitude = 5; % 5 * sin(2 * pi * freq)

periodoTest = 0.01;
hertzTest = [1 2 5 10 20 40 55 75 195 999];

NroCanal = 0;

%% Obtenci�n del periodo de muestreo y la frecuencia de la se�al
PeriodoMuestreo = input("Introduce el periodo de muestreo: ");
Frecuencia = input("Introduce la freciencia de la se�al (en hercios): ");

%% Exploraci�n del Hardware disponible 
Dispositivos = daq.getDevices;
Dispositivo = Dispositivos(1);

%% Creaci�n de la sesi�n 
Sesion = daq.createSession(Dispositivo.Vendor.ID);

%% %Inicializaci�n del canal 0 para la escritura en voltios
CanalOut = addAnalogOutputChannel(Sesion, Dispositivo.ID, NroCanal, 'Voltage');

%% Inicializaci�n del canal 0 para la lectura en voltios referida a masa
CanalIn = addAnalogInputChannel(Sesion, Dispositivo.ID, NroCanal, 'Voltage');
CanalIn.InputType = 'SingleEnded';

%% Bucle de prueba, necesario para que no se malformen las gr�ficas por el turbo del procesador
for t = 0:25
    Inicio = toc();
    timeToUse = toc();
    value = 5 * sin(2 * pi * Frecuencia * timeToUse);
    outputSingleScan(Sesion,value);
    Lectura = Sesion.inputSingleScan();
    Fin = toc();
    espera(max(0, PeriodoMuestreo-(Fin-Inicio)));
end


%% Bucle de muestreo
%for f = hertzTest
%    Frecuencia = f;
Time = [];
Sinusoidal = [];
SinusoidalLeida = [];
tic();
segundos = 1/Frecuencia * 4;

while toc() < segundos
    % Inicio = consulta del reloj
    Inicio = toc();
    % Lectura/escritura de datos
    timeToUse = toc();
    Time = [Time timeToUse];
    value = 5 * sin(2 * pi * Frecuencia * timeToUse);
    outputSingleScan(Sesion,value);
    Lectura = Sesion.inputSingleScan();
    SinusoidalLeida = [SinusoidalLeida Lectura];
    Sinusoidal = [Sinusoidal value];
    %fprintf("Lectura en la entrada del canal %d: %.3fV\n", NroCanal, Lectura);
    
    % Fin = consulta del reloj
    Fin = toc();
    % Espera (max(0, Periodo-(Fin-Inicio)))
    espera(max(0, PeriodoMuestreo-(Fin-Inicio)));
end
plot(Time, Sinusoidal);
hold on
[X, Y] = generaSinusoidalPura(Frecuencia, segundos);
plot(X, Y);
save(sprintf("variables_%dhz_2", f));
%end
%fprintf("Lectura en la entrada del canal ");
%% Al finalizar el programa hay que quitar la sesi�n 
release(Sesion);
%% Only plots of stored variables
%plot(Time, Sinusoidal);
%hold on
%plot(X, Y);

function [X, Y] = generaSinusoidalPura(hertz, segundos)
    Fs = 100000;
    dt = 1/Fs;
    StopTime = segundos; %seconds
    X = 0:dt:StopTime-dt;
    Y = 5 * sin(2 * pi * hertz * X);
end