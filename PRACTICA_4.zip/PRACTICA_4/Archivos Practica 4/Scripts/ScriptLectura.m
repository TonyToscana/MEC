% Ejercicio 2

%% Exploraci�n del Hardware disponible 
Dispositivos = daq.getDevices;
Dispositivo = Dispositivos(1);

%% Creaci�n de la sesi�n 
Sesion = daq.createSession(Dispositivo.Vendor.ID);

%% Inicializaci�n del canal 0 para la lectura en voltios referida a masa
NroCanal = 0;
CanalIn = addAnalogInputChannel(Sesion, Dispositivo.ID, NroCanal, 'Voltage');
CanalIn.InputType = 'SingleEnded';

%% Lectura en voltios por el canal de entrada configurado 
Lectura = Sesion.inputSingleScan();
fprintf("Lectura en la entrada del canal %d: %.3fV\n", NroCanal, Lectura);

%% Al finalizar el programa hay que quitar la sesi�n 
release(Sesion); 