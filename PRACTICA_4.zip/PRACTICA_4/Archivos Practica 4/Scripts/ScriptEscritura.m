% Ejercicio 3

%% Exploraci�n del Hardware disponible 
Dispositivos = daq.getDevices;
Dispositivo = Dispositivo(1);

%% Creaci�n de la sesi�n 
Sesion = daq.createSession(Dispositivo.Vendor.ID);

%% %Inicializaci�n del canal 0 para la escritura en voltios
NroCanal = 0;
CanalOut = addAnalogOutputChannel(Sesion, Dispositivo.ID, NroCanal, 'Voltage');

%%  Escritura en voltios por el canal de salida configurado
SalidaVolts = getUserInput();
%SalidaVolts = 5; %Voltios de salida entre -10 y +10
fprintf("Salida configurada en el canal %d a: %.2fV\n", NroCanal, SalidaVolts);
outputSingleScan(Sesion,SalidaVolts);

%% Al finalizar el programa hay que quitar la sesi�n 
release(Sesion); 



function out = getUserInput()
    out = 5;
    tmp = input("Introduce el voltaje (entre -10V y 10V, default 5V): ");
    if(tmp > 10 || tmp < -10)
        fprintf("El valor introducido se sale del rango, se usar� el valor por defecto.\n");
    else
        out = tmp;
    end
end